[云框架]基于Spring Cloud的微服务架构实例[PiggyMetrics](https://github.com/sqshq/PiggyMetrics)，点击查看[用户指南](https://github.com/cloudframeworks-springcloud/user-guide-springcloud)
